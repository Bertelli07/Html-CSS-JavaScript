//calculadora de desconto// 

// funcoes nomeadas//


function calcularDesconto(valorOriginal, percentualDesconto){
    const desconto = valorOriginal * (percentualDesconto / 100)
    return valorOriginal - desconto 
}

let precoOriginal = 100
let precoComDesconto = calcularDesconto(precoOriginal, 10)
console.log("Preco com desconto: R$ ",precoComDesconto)

//função anonima//

const mensagemFinal = function(nomeProduto,valorFinal)
{
    return `O produto ${nomeProduto} sai por ${valorFinal.toFixed(2)}` 
}
console.log(mensagemFinal("Camiseta",precoComDesconto))

let taxa = 5 // escopo global//

function aplicarTaxa(valor){
    let taxa = 10
    return valor + taxa
}

console.log("Valor final com taxa", aplicarTaxa(90))
console.log("Taxa : " ,taxa)



function calcularJurosSimples(valorOriginal, juros){
    const jurosSimples = valorOriginal * (juros / 100) * 30
    console.log(jurosSimples)
    return jurosSimples

}

const valorComJurosSimples = calcularJurosSimples(precoOriginal, 5)

console.log("Valor final com os juros de 5% no mes", valorComJurosSimples)


