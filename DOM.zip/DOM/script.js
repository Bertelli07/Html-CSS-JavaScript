// O que é o DOM?
// O DOM (Document Object Model) representa a estrutura HTML como objetos que o


// Selecionando elementos com getElementById
const titulo = document.getElementById("titulo");

// Selecionando com querySelector (pega o primeiro elemento que corresponde)
const mensagem = document.querySelector(".mensagem");

// Selecionando com querySelectorAll (retorna uma lista de elementos)
const paragrafos = document.querySelectorAll("p");

// Selecionando o botão
const botao = document.getElementById("botao");

// Adicionando um evento de clique no botão
botao.addEventListener("click", function() {

// Manipulação de texto com innerText
titulo.innerText = "Você clicou no botão!";



// Manipulando estilo diretamente com .style
document.body.style.backgroundColor = "#f0f8ff"; // Altera a cor de fundo

// Adicionando uma classe CSS usando classList
mensagem.classList.add("destaque");

// Usando querySelectorAll para modificar todos os parágrafos

paragrafos.forEach(function(p) {
p.innerText += " "; // Adiciona um símbolo em todos os <p>
});

});