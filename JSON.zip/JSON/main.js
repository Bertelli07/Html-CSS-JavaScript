//cadastro de produtos

//criar o objeto
let produto = {
    nome: "Camiseta",
    preco: 49.90,
    emEstoque: true,
    tamanhos: ["P", "M", "G"],
    detalhes: {
        cor: "Azul",
        material: "Algodão"
    }
}

//acessar os objetos
console.log("Produto: ", produto.nome)
console.log("Preço: ", produto.preco)
console.log("Está em estoque? ", produto.emEstoque)

console.log("Tamanhos disponíveis: ", produto.tamanhos.join(", "))
console.log("Cor: ", produto.detalhes.cor)

//modificar valores

produto.preco = 59.90
produto.emEstoque = false
produto.tamanhos.push("GG")

//adicionar uma nova propriedade
produto.categoria = "Roupas"

//Remove uma propriedade
delete produto.detalhes.material

console.log("Produto: ", produto.nome)
console.log("Preço: ", produto.preco)
console.log("Está em estoque? ", produto.emEstoque)

console.log("Tamanhos disponíveis: ", produto.tamanhos.join(", "))
console.log("Cor: ", produto.detalhes.cor)
console.log("Categoria: ", produto.categoria)

//converter objeto em json
let jsonProduto = JSON.stringify(produto)
console.log("Objeto em JSON: ", jsonProduto)

//converter JSON em objeto

let produtoConvertido = JSON.parse(jsonProduto)
console.log("Objeto convertido: ", produtoConvertido)
