// funcao de callback efetiva


const inputNome = document.getElementById("nome");

const botao = document.getElementById("botao");         // define as variaveis para os botoes e nomes, para armazenar-las

const saudacao = document.getElementById("saudacao");


function exibirSaudacao(){
    const nome = inputNome.value //captura o valor digitado do input
    
    saudacao.innerText = `Olá ${nome}, Seja muito bem vindo!`  // alterando o texto do paragrafo

}

botao.addEventListener("click", exibirSaudacao);


botao.addEventListener("mouseover", function(){
    botao.style.backgroundColor = "lightgreen";

}
)

inputNome.addEventListener("input", function(){
    //alert("Texto sendo digitado...")
})

inputNome.addEventListener("keydown", function(event){
        alert(`Tecla Pressionada: ${event.key}`)
})
